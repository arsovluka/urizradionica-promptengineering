from colorama import init, Fore, Style

init(autoreset=True)

def check_password_strength(password):
    score = 0
    feedback = []
    
    # Provera dužine
    if len(password) >= 8:
        score += 1
    else:
        feedback.append("- koristite najmanje 8 karaktera")
    
    if len(password) >= 12:
        score += 1
    else:
        if len(password) >= 8:
            feedback.append("- povećajte dužinu na 12+ karaktera za veću sigurnost")
    
    # Provera brojeva
    if any(c.isdigit() for c in password):
        score += 1
    else:
        feedback.append("- dodajte bar jedan broj")
    
    # Provera velikih slova
    if any(c.isupper() for c in password):
        score += 1
    else:
        feedback.append("- dodajte bar jedno veliko slovo")
    
    # Provera malih slova
    if any(c.islower() for c in password):
        score += 1
    else:
        feedback.append("- dodajte bar jedno malo slovo")
    
    # Provera specijalnih znakova
    special_chars = "!@#$%^&*()-_=+[]{}|;:,.<>?/"
    if any(c in special_chars for c in password):
        score += 1
    else:
        feedback.append("- dodajte bar jedan specijalni znak (!@#$%^&* itd.)")
    
    # Određivanje ocene i boje
    if score <= 3:
        return "Weak", Fore.RED, feedback
    elif score <= 5:
        return "Medium", Fore.YELLOW, feedback
    else:
        return "Strong", Fore.GREEN, feedback

print("=== Provera jačine lozinke ===\n")
password = input("Unesite lozinku: ")
strength, color, feedback = check_password_strength(password)

print(color + f"\nJačina lozinke: {strength}" + Style.RESET_ALL)

if feedback:
    print("\n📝 Saveti za poboljšanje:")
    for savet in feedback:
        print(savet)
else:
    print("\n✅ Odlično! Lozinka je jaka!")