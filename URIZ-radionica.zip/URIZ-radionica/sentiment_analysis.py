from textblob import TextBlob
from colorama import init, Fore, Style

init(autoreset=True)

print("=== AI Sentiment Analiza ===")
print("Unesi rečenicu, ja ću reći da li je pozitivna, negativna ili neutralna.")
print("Za izlaz unesi: exit\n")

while True:
    tekst = input("Ti: ")
    if tekst.lower() == "exit":
        print("Doviđenja!")
        break
    
    blob = TextBlob(tekst)
    polarity = blob.sentiment.polarity
    
    if polarity > 0:
        boja = Fore.GREEN
        ocena = "POZITIVAN"
    elif polarity < 0:
        boja = Fore.RED
        ocena = "NEGATIVAN"
    else:
        boja = Fore.YELLOW
        ocena = "NEUTRALAN"
    
    print(boja + f"AI: {ocena} (polaritet: {polarity:.2f})" + Style.RESET_ALL)
    print()